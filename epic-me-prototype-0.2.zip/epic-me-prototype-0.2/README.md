# Epic Me — Prototype 0.2

## What's new
- New landing screen with the approved opening copy and two buttons: **Begin my adventure** and **Continue my journey**.
- Beginning your adventure opens **Level 1: Me, Myself, & I** onboarding.
- Vintage tavern-inspired branding: warm walnut, parchment, brass, and an old character-sheet aesthetic (not a literal tavern setting).
- **Elements of Me** replaces Community Residents in the player-facing navigation.
- Added an initial **My Character Sheet** with seven base abilities: Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma, and Integration. Figures here are counts of loosely related recorded experiences, *not* measured ability scores.
- Observations can now be marked as **recent experiences** or **memories**.
- Personal data stays in browser local storage; this version has no AI integration.

## Run on iPhone using your existing GitHub Pages site
1. Save a backup first if you want to preserve previous progress: in the existing game open **My Story → Export my data**.
2. Download the new **index.html** from this package to Files on your iPhone.
3. Open your existing `epic-me` GitHub repository in Safari. Use **Add file → Upload files**, or navigate to `https://github.com/YOUR-USERNAME/epic-me/upload/main`.
4. Upload this new `index.html` directly into the repository root. GitHub should offer to **replace** the existing file; commit the change.
5. Open the same GitHub Pages URL as before. If the old version persists, refresh Safari.

**Important:** This prototype deliberately retains the `epic-me-prototype-v1` local-storage key, so existing progress should remain on the same site and browser. Using **Begin my adventure** when you already have progress will prompt before resetting the saved game; choose **Continue my journey** to preserve it.

## Privacy
Don't use this prototype for private medical details, passwords, financial credentials, government IDs, or identifying information about other people. Data is in browser storage (not encrypted by the app), and a website host may log ordinary web requests. There is no connected AI, login, sync, or server-side storage of entered experiences.

## Scope
Prototype 0.2 is a functional design iteration, not a validated assessment. Attribute evidence matching is a simple word-based approximation. XP and achievements remain prototype rules, not objective measurements of personal development.
